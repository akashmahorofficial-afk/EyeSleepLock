package com.example.eyesleeplock

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var dpm: DevicePolicyManager
    private lateinit var admin: ComponentName

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
        admin = ComponentName(this, AdminReceiver::class.java)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        status = TextView(this).apply { textSize = 16f }
        val info = TextView(this).apply {
            text = "Turns the screen off when your eyes stay closed for ~1.5 seconds."
            setPadding(0, 0, 0, pad)
        }
        val adminBtn = Button(this).apply {
            text = "1. Grant lock-screen permission"
            setOnClickListener {
                startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                    putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                    putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "Needed to turn the screen off when your eyes are closed.")
                })
            }
        }
        val startBtn = Button(this).apply {
            text = "2. Start monitoring"
            setOnClickListener { start() }
        }
        val stopBtn = Button(this).apply {
            text = "Stop monitoring"
            setOnClickListener {
                stopService(Intent(this@MainActivity, EyeMonitorService::class.java))
                refresh("Stopped")
            }
        }
        listOf(info, status, adminBtn, startBtn, stopBtn).forEach { root.addView(it) }
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh(msg: String? = null) {
        val a = if (dpm.isAdminActive(admin)) "granted" else "NOT granted"
        status.text = "Lock permission: $a" + (msg?.let { "\n$it" } ?: "")
    }

    private fun start() {
        if (!dpm.isAdminActive(admin)) { refresh("Grant lock permission first."); return }
        val needed = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) needed += Manifest.permission.POST_NOTIFICATIONS
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1)
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, EyeMonitorService::class.java))
        refresh("Monitoring…")
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) start()
        else refresh("Camera permission is required.")
    }
}
