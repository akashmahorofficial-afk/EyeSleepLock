package com.example.eyesleeplock

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.admin.DevicePolicyManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.SystemClock
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.Executors

class EyeMonitorService : LifecycleService() {

    private val executor = Executors.newSingleThreadExecutor()
    private val detector by lazy {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
                .build()
        )
    }

    private val CLOSED_THRESHOLD = 0.3f      // eye-open probability below this = closed
    private val CLOSED_MS = 1500L            // eyes must stay closed this long

    @Volatile private var closedSince = 0L
    @Volatile private var paused = false

    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            closedSince = 0L
            paused = false
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundNow()
        ContextCompat.registerReceiver(
            this, unlockReceiver, IntentFilter(Intent.ACTION_USER_PRESENT),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        startCamera()
    }

    private fun startForegroundNow() {
        val chId = "eye_monitor"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(chId, "Eye monitoring", NotificationManager.IMPORTANCE_LOW)
        )
        val n = NotificationCompat.Builder(this, chId)
            .setContentTitle("Eye Sleep Lock is active")
            .setContentText("Screen turns off when your eyes are closed")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        else startForeground(1, n)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analysis.setAnalyzer(executor) { analyze(it) }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    @androidx.annotation.OptIn(androidx.camera.core.ExperimentalGetImage::class)
    private fun analyze(proxy: ImageProxy) {
        val media = proxy.image
        if (media == null || paused) { proxy.close(); return }
        val img = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
        detector.process(img)
            .addOnSuccessListener { faces ->
                val face = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() }
                val l = face?.leftEyeOpenProbability
                val r = face?.rightEyeOpenProbability
                if (l != null && r != null && l < CLOSED_THRESHOLD && r < CLOSED_THRESHOLD) {
                    val now = SystemClock.elapsedRealtime()
                    if (closedSince == 0L) closedSince = now
                    else if (now - closedSince >= CLOSED_MS) lockScreen()
                } else {
                    closedSince = 0L   // eyes open, or no face visible
                }
            }
            .addOnCompleteListener { proxy.close() }
    }

    private fun lockScreen() {
        paused = true
        closedSince = 0L
        val dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (dpm.isAdminActive(ComponentName(this, AdminReceiver::class.java))) dpm.lockNow()
    }

    override fun onDestroy() {
        unregisterReceiver(unlockReceiver)
        detector.close()
        executor.shutdown()
        super.onDestroy()
    }
}
