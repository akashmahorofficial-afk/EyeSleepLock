package com.example.eyesleeplock

import android.app.admin.DeviceAdminReceiver

class AdminReceiver : DeviceAdminReceiver()
